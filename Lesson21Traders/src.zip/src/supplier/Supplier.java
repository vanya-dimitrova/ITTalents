package supplier;

import java.util.ArrayList;
import java.util.Random;

public abstract class Supplier {

	protected String name;
	protected String address;
	private int workingHours;
	protected double discount;
	protected ArrayList<Product> products;
	protected int maxProducts;

	Supplier(String name) {
		this.address = "Sofia";
		this.workingHours = 8;
		if (name != null) {
			this.name = name;
		} 
		else {
			throw new IllegalArgumentException("Invalid input! Object is not created!");
		}
	}
	
	public ArrayList<Product> getProducts(){
		return this.products;
	}
	
	public double getDiscount(){
		return this.discount;
	}
	
	public void addProducts(){
		Product socks = new Product("socks", 5.50);
		Product scarf = new Product("scarf", 10.50);
		Product hat = new Product("hat", 12.50);
		Product gloves = new Product("gloves", 9.99);
		Product tshirt = new Product("t-shirt", 15.00);
		Product stockings = new Product("stockings", 6.00);
		Product panties = new Product("panties", 5.00);
		Product sweatshirt = new Product("sweatshirt", 14.99);
		Product skirt = new Product("skirt", 15.00);
		Product pants = new Product("pants", 15.00);
		
		for (int i = 0; i < this.maxProducts; i++) {
			switch(new Random().nextInt(10)){
			case 0:
				this.products.add(socks);
				break;
			case 1:
				this.products.add(scarf);
				break;
			case 2:
				this.products.add(hat);
				break;
			case 3:
				this.products.add(gloves);
				break;
			case 4:
				this.products.add(tshirt);
				break;
			case 5:
				this.products.add(stockings);
				break;
			case 6:
				this.products.add(panties);
				break;
			case 7:
				this.products.add(sweatshirt);
				break;
			case 8:
				this.products.add(skirt);
				break;
			case 9:
				this.products.add(pants);
				break;
			}
		}
		
	}
	

}
