package supplier;

public class Product {
	
	public final String name;
	public double price;
	
	public Product(String name, double price){
		this.name = name;
		this.price = price;
	}
	
	public void setPrice(Supplier supplier){
		this.price *= supplier.discount;
	}
	
	
	
	

}
