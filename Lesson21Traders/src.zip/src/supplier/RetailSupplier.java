package supplier;

import java.util.Random;

public class RetailSupplier extends Supplier {
	
	public RetailSupplier(String name){
		super(name);
		this.discount = 0.00;
		this.maxProducts = 30;
		this.addProducts();
	}

	
		

}
