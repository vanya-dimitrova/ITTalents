package supplier;

import java.util.Random;

public class WholeSaleSupplier extends Supplier {
	
	public WholeSaleSupplier(String name){
		super(name);
		this.discount = 0.15;
		this.maxProducts = 50;
		this.addProducts();
		
	}

		
		

}
