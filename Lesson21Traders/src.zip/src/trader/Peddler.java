package trader;

import java.util.ArrayList;
import java.util.Random;
import supplier.*;

public class Peddler extends Trader {

	RetailSupplier supplier;
	ArrayList<Product> products;

	
	public Peddler(String name, ArrayList suppliers) {
		super(name);
		this.money = 100.00;
		while (this.supplier == null) {
			Random r = new Random();
			int index = r.nextInt(suppliers.size());
			if (suppliers.get(index) instanceof RetailSupplier) {
				this.supplier = (RetailSupplier) suppliers.get(index);
				suppliers.remove(index);
			}
		}
	}

	
	@Override
	public void makeOrder() {
		int moneyToSpend = (int) (this.money / 2);
		while (moneyToSpend >= 15) {
			
			//add products to supplier if necessary
			int index = this.supplier.getProducts().size() - 1;
			if (supplier.getProducts().size() < 1) {
				supplier.addProducts();
			}
			// buy products and sort by price, check discount, regulate money
			for (int i = 0; i < this.products.size(); i++) {
				if (this.supplier.getProducts().get(index).price <= this.products.get(i).price) {
					this.products.add(i, this.supplier.getProducts().get(index));
					this.products.get(i).setPrice(this.supplier);
					break;
				} else if (i == this.products.size() - 1) {
					this.products.add(this.supplier.getProducts().get(index));
					this.products.get(i).setPrice(this.supplier);
					break;
				}
			}
			this.money -= this.supplier.getProducts().get(index).price * this.supplier.getDiscount();
			moneyToSpend -= this.supplier.getProducts().get(index).price * this.supplier.getDiscount();
			this.supplier.getProducts().remove(index);
		}
		System.out.println("Products in shop:");
		this.products.toString();

	}

	
	@Override
	public void addTurnoverToMoney() {
		double turnover = 0;
		double profit = 0;
		int numberOfProductsSold = new Random().nextInt(this.products.size());
		for (int i = 0; i < numberOfProductsSold; i++) {
			int index = new Random().nextInt(this.products.size());
			turnover += this.products.get(index).price * this.priceFormationPercentage;
			profit += this.products.get(index).price * this.profitPercentage;
			this.products.remove(index);
		}
		System.out.println("Dayly profit: " + profit);
		this.numberOfProductsSold += numberOfProductsSold;
		this.money += turnover;
	}

	
	@Override
	public void payTax() {
	}

}