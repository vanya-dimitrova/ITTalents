package trader;

public abstract class Trader {
	
	private String name;
	private String address;
	protected double money;
	protected int numberOfProductsSold;
	protected double priceFormationPercentage;
	protected double profitPercentage;
	
	public Trader(String name){
		this.address = "Sofia";
		this.priceFormationPercentage = 1.3;
		this.profitPercentage = 0.3;
		if(name != null){
			this.name = name;
		}
		else{
			throw new IllegalArgumentException("Invalid input! Object is not created!");
		}
	}
	
	public double getMoney(){
		return this.money;
	}
	
	abstract public void makeOrder();
				
		
	abstract public void addTurnoverToMoney();
	   
	
	abstract public void payTax();
	
	

}
