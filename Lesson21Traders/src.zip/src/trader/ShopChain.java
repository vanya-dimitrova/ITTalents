package trader;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Random;

import supplier.Product;
import supplier.Supplier;
import tradingObject.ITradingObjectsShopChain;
import tradingObject.MarketTable;
import tradingObject.StreetShop;

public class ShopChain extends Trader {

	private ArrayList<Supplier> suppliers;
	private ArrayList<Product> products;
	public ArrayList<ITradingObjectsShopChain> tradingObjects;

	public ShopChain(String name, ArrayList suppliers, ArrayList tradingObjects) {
		super(name);
		this.money = 3000.00;
		int index = new Random().nextInt(14) + 2;
		for (int i = 0; i < suppliers.size(); i++) {
			if ((this.suppliers.size() == index)) {
				break;
			}
		}

	}

	@Override
	public void makeOrder() {
		// for each shop
		for (int i = 0; i < this.tradingObjects.size(); i++) {
			ITradingObjectsShopChain currentTradingObject = this.tradingObjects.get(i);
			int moneyToSpend = (int) (this.money / this.tradingObjects.size() / 2);
			while (moneyToSpend >= 15) {

				// add products to supplier if necessary
				Supplier currentSupplier = this.suppliers.get(new Random().nextInt(this.suppliers.size()));
				int index = currentSupplier.getProducts().size() - 1;
				if (currentSupplier.getProducts().size() < 1) {
					currentSupplier.addProducts();
				}
				// buy products and sort by price, check discount, regulate
				// money
				for (int j = 0; j < this.products.size(); j++) {
					if (currentSupplier.getProducts().get(index).price <= this.products.get(j).price) {
						this.products.add(j, currentSupplier.getProducts().get(index));
						this.products.get(j).setPrice(currentSupplier);
						break;
					} else if (j == this.products.size() - 1) {
						this.products.add(currentSupplier.getProducts().get(index));
						this.products.get(j).setPrice(currentSupplier);
						break;
					}
				}
				this.money -= currentSupplier.getProducts().get(index).price * currentSupplier.getDiscount();
				moneyToSpend -= currentSupplier.getProducts().get(index).price * currentSupplier.getDiscount();
				currentSupplier.getProducts().remove(index);
			}
			for (int j = 0; j < this.tradingObjects.get(i).getProducts().size(); j++) {
				System.out.println("'Chain shops' products in shop " + i + ": ");
				System.out.println(this.tradingObjects.get(i).getProducts().get(j).name + " - "
						+ this.tradingObjects.get(i).getProducts().get(j).price);
			}
		}
	}

	
	@Override
	public void addTurnoverToMoney() {
		for (int i = 0; i < this.tradingObjects.size(); i++) {
			double turnover = 0;
			double profit = 0;
			int numberOfProductsSold = new Random().nextInt(this.tradingObjects.get(i).getProducts().size());
			for (int j = 0; j < numberOfProductsSold; j++) {
				int index = new Random().nextInt(this.tradingObjects.get(j).getProducts().size());
				turnover += this.tradingObjects.get(j).getProducts().get(index).price * this.priceFormationPercentage;
				profit += this.tradingObjects.get(j).getProducts().get(index).price * this.profitPercentage;
				this.tradingObjects.get(j).getProducts().remove(index);
			}
			System.out.println("'Chain shops' daily profit shop " + i + ": " + profit);
			this.numberOfProductsSold += numberOfProductsSold;
			this.money += turnover;
		}
	}

	@Override
	public void payTax() {
		for (int i = 0; i < this.tradingObjects.size(); i++) {
			this.money -= this.tradingObjects.get(i).getTax() / 365;
		}
	}

}
