
public class HomeworkTask2 {

	public static void main(String[] args) {
		
		int[] arr = {3, 5, 7, 9, 11, 13};
		int[] arrnew = new int[arr.length];
		
		int i = 0;
		int a = 0;
		for(i = 0; i < arr.length/2; i++){
			arrnew[a] = arr[i];
			System.out.print(arrnew[a]+" ");
			a++;
		}
		for(i = arr.length - 1; i >= arr.length/2; i--){
			a = arrnew.length/2 - 1;
			arrnew[a] = arr[i];
			System.out.print(arrnew[a]+" ");
			a++;
		}
			
		
		

		
		

	}

}
