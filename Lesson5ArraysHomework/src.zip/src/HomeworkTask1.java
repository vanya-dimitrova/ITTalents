import java.util.Scanner;

public class HomeworkTask1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Enter lenght value for the array:" );
		int lenght = sc.nextInt();
		
		int[] arr = new int[lenght];
		System.out.println("Enter array values:");
		int i = 0;
		for(i = 0; i < arr.length; i++){
				arr[i] = sc.nextInt();
		}
		int kratno = 0;
		int sumkratno = 0;
		for(i = 0; i < arr.length; i++){
			kratno = arr[i]%3;
			if(kratno == 0){
				kratno = 1;
				sumkratno +=kratno;
			}
		}
		int[] arrnew = new int[sumkratno];
		int a = 0;
			for(i = 0; i < arr.length; i++){
				kratno = arr[i]%3;
				if(kratno == 0){
					arrnew[a] = arr[i];
					a++;
				}
			}
			int aa = 0;
			for(a = 0; a < arrnew.length; a++){
				for(aa = 0; aa < arrnew.length; aa++){
					if(arrnew[a] >= arrnew[aa]){
						break;
					}
					else if(arrnew[aa] < arrnew.length){
						System.out.println("Nai malkoto kratno chislo na tri e "+arrnew[a]);
					}
				}
				
			}
			
		
			
			
		
		

	}

}
