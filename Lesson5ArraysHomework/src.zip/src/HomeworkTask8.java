
public class HomeworkTask8 {

	public static void main(String[] args) {
		
		int[] arr = {1, 2, 5, 1, 3, 8, 8, 4, 8, 3, 3, 3, 9};
		
		int i = 0;
		int ii = 0;
		for(i = 0; i < arr.length; i++){
			if(arr[i] == arr[i+1]){
				do{
				int count = 0;
				count+=1;
				ii = i;
				}
				while(arr[i] == arr[i+1] || i == arr.length - 1);
			}
			
		}
		

	}

}
